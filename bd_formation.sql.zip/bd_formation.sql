-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Mercredi 20 Avril 2011 à 21:57
-- Version du serveur: 5.0.17
-- Version de PHP: 5.1.1
-- 
-- Base de données: `bd_formation`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `competence`
-- 

CREATE TABLE `competence` (
  `id_ens` varchar(50) NOT NULL,
  `id_d` varchar(50) NOT NULL,
  `comp` text NOT NULL,
  PRIMARY KEY  (`id_ens`,`id_d`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `competence`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `convention`
-- 

CREATE TABLE `convention` (
  `id_conv` int(10) NOT NULL auto_increment,
  `id_ens` varchar(50) NOT NULL,
  `id_d` varchar(50) NOT NULL,
  `lib_conv` int(11) NOT NULL,
  `dat_d_con` date NOT NULL,
  `dat_d_conv` date NOT NULL,
  `observ_ens_conv` text NOT NULL,
  PRIMARY KEY  (`id_conv`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `convention`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `cours`
-- 

CREATE TABLE `cours` (
  `id_cr` varchar(10) NOT NULL,
  `lib_cr` varchar(100) NOT NULL,
  `object_CR` text NOT NULL,
  PRIMARY KEY  (`id_cr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `cours`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `decipline`
-- 

CREATE TABLE `decipline` (
  `id_d` varchar(10) NOT NULL,
  `lib_d` varchar(50) NOT NULL,
  `objectif_d` text NOT NULL,
  `cout_d` float NOT NULL,
  `id_dip` int(10) NOT NULL,
  PRIMARY KEY  (`id_d`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `decipline`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `diplome`
-- 

CREATE TABLE `diplome` (
  `id_dip` int(10) NOT NULL auto_increment,
  `formulair_dip` varchar(100) NOT NULL,
  `lib_dip` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_dip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `diplome`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `droit`
-- 

CREATE TABLE `droit` (
  `id_droi` int(2) NOT NULL,
  `lib_droi` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_droi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `droit`
-- 

INSERT INTO `droit` VALUES (1, 'g_centre');
INSERT INTO `droit` VALUES (2, 'g_reglement');
INSERT INTO `droit` VALUES (3, 'g_personel');
INSERT INTO `droit` VALUES (4, 'g_formation');
INSERT INTO `droit` VALUES (5, 'g_matiére');
INSERT INTO `droit` VALUES (6, 'g_salle');

-- --------------------------------------------------------

-- 
-- Structure de la table `droit_util`
-- 

CREATE TABLE `droit_util` (
  `id_util` varchar(50) NOT NULL,
  `id_droi` char(1) NOT NULL,
  `etat_droi` char(1) NOT NULL,
  PRIMARY KEY  (`id_util`,`id_droi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `droit_util`
-- 

INSERT INTO `droit_util` VALUES ('util1', '1', 'o');
INSERT INTO `droit_util` VALUES ('util1', '2', 'o');
INSERT INTO `droit_util` VALUES ('util1', '3', 'o');
INSERT INTO `droit_util` VALUES ('util', '4', 'n');
INSERT INTO `droit_util` VALUES ('util1', '5', 'n');
INSERT INTO `droit_util` VALUES ('util1', '6', 'o');
INSERT INTO `droit_util` VALUES ('util2', '6', 'o');
INSERT INTO `droit_util` VALUES ('util2', '5', 'o');
INSERT INTO `droit_util` VALUES ('util2', '1', 'n');
INSERT INTO `droit_util` VALUES ('util2', '2', 'n');
INSERT INTO `droit_util` VALUES ('util2', '3', 'n');
INSERT INTO `droit_util` VALUES ('util2', '4', 'n');

-- --------------------------------------------------------

-- 
-- Structure de la table `ecole_centre`
-- 

CREATE TABLE `ecole_centre` (
  `id_e` varchar(50) NOT NULL,
  `logo_e` varchar(100) NOT NULL,
  `raison_soc_e` varchar(50) NOT NULL,
  `MP_e` varchar(100) NOT NULL,
  `RC_e` varchar(100) NOT NULL,
  `adres_e` varchar(100) NOT NULL,
  `cod_p_e` int(5) NOT NULL,
  `tel_fix1_e` int(8) NOT NULL,
  `tel_fix2_e` int(8) NOT NULL,
  `tel_port1_e` int(8) NOT NULL,
  `tel_port2_e` int(8) NOT NULL,
  `fax_e` int(8) NOT NULL,
  `email_e` varchar(100) NOT NULL,
  `sit_web_e` varchar(100) NOT NULL,
  `ville_e` varchar(50) NOT NULL,
  `CCB_e` varchar(50) NOT NULL,
  `RIB_e` varchar(50) NOT NULL,
  `banque_e` varchar(50) NOT NULL,
  `responsable_e` varchar(100) NOT NULL,
  `GSM_e` varchar(50) NOT NULL,
  `observ_e` text NOT NULL,
  PRIMARY KEY  (`id_e`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `ecole_centre`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `enseignant`
-- 

CREATE TABLE `enseignant` (
  `id_ens` int(10) NOT NULL,
  `nom_ens` varchar(50) NOT NULL,
  `prenom_ens` varchar(100) NOT NULL,
  `sexe_ens` char(1) NOT NULL,
  `dat_nais_ens` date NOT NULL,
  `lieu_ens` varchar(100) NOT NULL,
  `adres_ens` varchar(200) NOT NULL,
  `cod_p_ens` int(8) NOT NULL,
  `pay_ens` varchar(19) NOT NULL,
  `email_ens` varchar(100) NOT NULL,
  `tel_fix_ens` int(8) NOT NULL,
  `tel_port1_ens` int(8) NOT NULL,
  `tel_port2_ens` int(8) NOT NULL,
  `fax_ens` int(8) NOT NULL,
  `cin_ens` int(8) NOT NULL,
  `observ_ens` text NOT NULL,
  `solde_ens` float NOT NULL,
  PRIMARY KEY  (`id_ens`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `enseignant`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `etudiant`
-- 

CREATE TABLE `etudiant` (
  `id_et` int(8) NOT NULL,
  `nom_et` varchar(60) NOT NULL,
  `prenom_et` varchar(100) NOT NULL,
  `photo_et` varchar(150) NOT NULL,
  `dat_nais_et` date NOT NULL,
  `lieu_et` varchar(150) NOT NULL,
  `adres_et` varchar(150) NOT NULL,
  `cod_p_et` int(5) NOT NULL,
  `tel_fix_et` int(8) NOT NULL,
  `tel_por1_et` int(8) NOT NULL,
  `tel_por2_et` int(8) NOT NULL,
  `fax_et` int(8) NOT NULL,
  `niv_scolair_et` varchar(50) NOT NULL,
  `etablissemen_social_et` varchar(60) NOT NULL,
  `fonction_et` varchar(100) NOT NULL,
  `observ_et` varchar(200) NOT NULL,
  `cin` int(8) NOT NULL,
  `solde` float NOT NULL,
  `pays_et` varchar(20) NOT NULL,
  `email_et` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_et`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `etudiant`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `exam_et`
-- 

CREATE TABLE `exam_et` (
  `id_et` varchar(50) NOT NULL,
  `id_ex` int(10) NOT NULL,
  `note_ex` float NOT NULL,
  PRIMARY KEY  (`id_et`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `exam_et`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `examun`
-- 

CREATE TABLE `examun` (
  `id_ex` int(10) NOT NULL auto_increment,
  `lib_ex` varchar(50) NOT NULL,
  `id_f` varchar(50) NOT NULL,
  `id_et` varchar(50) NOT NULL,
  `dat_ex` date NOT NULL,
  `dure_ex` varchar(5) NOT NULL,
  PRIMARY KEY  (`id_ex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `examun`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `form_ens`
-- 

CREATE TABLE `form_ens` (
  `id_f` varchar(50) NOT NULL,
  `id_ens` varchar(50) NOT NULL,
  `nb_h_f_ens` int(2) NOT NULL,
  `prix_f_ens` float NOT NULL,
  PRIMARY KEY  (`id_f`,`id_ens`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `form_ens`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `form_et`
-- 

CREATE TABLE `form_et` (
  `id_f` varchar(50) NOT NULL,
  `id_et` varchar(50) NOT NULL,
  `nb_h_f_et` int(2) NOT NULL,
  `prix_f_et` float NOT NULL,
  PRIMARY KEY  (`id_f`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `form_et`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `formation`
-- 

CREATE TABLE `formation` (
  `id_f` varchar(50) NOT NULL,
  `lib_f` varchar(50) NOT NULL,
  `id_m` varchar(50) NOT NULL,
  `id_d` varchar(50) NOT NULL,
  `id_cr` varchar(50) NOT NULL,
  `nb_h_f` int(2) NOT NULL,
  `nb_sem_f` int(2) NOT NULL,
  `prix_f` float(20,3) NOT NULL,
  `observation_f` text NOT NULL,
  `dat_d_f` date NOT NULL,
  `dat_f_f` date NOT NULL,
  `id_ex` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `formation`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `fournissuer`
-- 

CREATE TABLE `fournissuer` (
  `id_fr` varchar(50) NOT NULL,
  `raison_soc_fr` varchar(100) NOT NULL,
  `MF_fr` varchar(100) NOT NULL,
  `RC_fr` varchar(100) NOT NULL,
  `adres_fr` varchar(100) NOT NULL,
  `cod_p_fr` int(8) NOT NULL,
  `ville_fr` varchar(50) NOT NULL,
  `tel_fix1_fr` int(8) NOT NULL,
  `tel_fix2_fr` int(8) NOT NULL,
  `tel_port1_fr` int(8) NOT NULL,
  `tel_port2_fr` int(8) NOT NULL,
  `fax_fr` int(8) NOT NULL,
  `email_fr` varchar(100) NOT NULL,
  `site_web_fr` varchar(100) NOT NULL,
  `banque_fr` varchar(100) NOT NULL,
  `RIB_fr` varchar(100) NOT NULL,
  `responsable_fr` varchar(100) NOT NULL,
  `GSM` varchar(50) NOT NULL,
  `solde_fr` float NOT NULL,
  `observ_fr` text NOT NULL,
  PRIMARY KEY  (`id_fr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `fournissuer`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `jour`
-- 

CREATE TABLE `jour` (
  `id_jr` int(1) NOT NULL,
  `lib_jr` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_jr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `jour`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `journal_evenement`
-- 

CREATE TABLE `journal_evenement` (
  `id_j_evn` int(200) NOT NULL auto_increment,
  `lib_evn` text NOT NULL,
  `dat_evn` date NOT NULL,
  `id_util` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_j_evn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `journal_evenement`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `journale_caisse`
-- 

CREATE TABLE `journale_caisse` (
  `id_cais` int(30) NOT NULL auto_increment,
  `descr_cais` text NOT NULL,
  `dat_cais` date NOT NULL,
  `heur_cais` varchar(5) NOT NULL,
  `mt_vers_cais` float NOT NULL,
  `mt_retire_cais` float NOT NULL,
  `mt_cheq_cais` float NOT NULL,
  `mt_espec_cais` float NOT NULL,
  `id_ens_reg` int(100) NOT NULL,
  `id_et_reg` int(100) NOT NULL,
  `id_fr_reg` int(100) NOT NULL,
  `lib_piece` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_cais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `journale_caisse`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `matiere`
-- 

CREATE TABLE `matiere` (
  `id_mat` varchar(8) NOT NULL,
  `lib_mat` varchar(50) NOT NULL,
  `object_mat` text NOT NULL,
  PRIMARY KEY  (`id_mat`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `matiere`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `periode`
-- 

CREATE TABLE `periode` (
  `id_per` int(2) NOT NULL,
  `lib_per` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_per`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `periode`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `plan_jour`
-- 

CREATE TABLE `plan_jour` (
  `id_jr` int(1) NOT NULL,
  `id_p` int(10) NOT NULL,
  PRIMARY KEY  (`id_jr`,`id_p`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `plan_jour`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `plan_period`
-- 

CREATE TABLE `plan_period` (
  `id_p` int(10) NOT NULL,
  `id_per` int(2) NOT NULL,
  `etat_plan` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_p`,`id_per`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `plan_period`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `planning`
-- 

CREATE TABLE `planning` (
  `id_p` int(10) NOT NULL auto_increment,
  `dat_p` date NOT NULL,
  `id_et` varchar(50) NOT NULL,
  `id_ens` varchar(50) NOT NULL,
  `id_sal` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_p`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `planning`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `pre_inscrit`
-- 

CREATE TABLE `pre_inscrit` (
  `id_f` varchar(50) NOT NULL,
  `id_et` varchar(50) NOT NULL,
  `etat_et_f` varchar(2) NOT NULL,
  `acompte_et_f` float NOT NULL,
  `observ_et_f` text NOT NULL,
  `dat_ins_f` date NOT NULL,
  PRIMARY KEY  (`id_f`,`id_et`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `pre_inscrit`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `presence_ens`
-- 

CREATE TABLE `presence_ens` (
  `id_ens` varchar(50) NOT NULL,
  `id_s` int(10) NOT NULL,
  `etat_p_ens` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_ens`,`id_s`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `presence_ens`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `presence_et`
-- 

CREATE TABLE `presence_et` (
  `id_ens` varchar(50) NOT NULL,
  `id_s` int(10) NOT NULL,
  `etat_p_et` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_ens`,`id_s`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `presence_et`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `reg_ens`
-- 

CREATE TABLE `reg_ens` (
  `id_reg_ens` int(50) NOT NULL auto_increment,
  `dat_reg_ens` date NOT NULL,
  `id_ens` varchar(50) NOT NULL,
  `id_f` varchar(50) NOT NULL,
  `lib_reg_ens` varchar(50) NOT NULL,
  `debit_reg_ens` float NOT NULL,
  `credit_reg_ens` float NOT NULL,
  `solde_reg_ens` float NOT NULL,
  `rest_reg_ens` float NOT NULL,
  `mod_pay_reg_ens` varchar(2) NOT NULL,
  `echeance_reg_ens` float NOT NULL,
  `retenu_reg_ens` float NOT NULL,
  `observ_reg_ens` text NOT NULL,
  PRIMARY KEY  (`id_reg_ens`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `reg_ens`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `reg_et`
-- 

CREATE TABLE `reg_et` (
  `id_et` varchar(8) NOT NULL,
  `id_f` varchar(10) NOT NULL,
  `dat_reg_et` date NOT NULL,
  `lib_reg_et` varchar(50) NOT NULL,
  `debit_reg_et` float NOT NULL,
  `credit_reg_et` float NOT NULL,
  `solde_reg_et` float NOT NULL,
  `rest_pay_reg_et` float NOT NULL,
  `mod_pay_reg_et` varchar(3) NOT NULL,
  `echeance_reg_et` float NOT NULL,
  `retenu_reg_et` float NOT NULL,
  `observation_reg_et` text NOT NULL,
  PRIMARY KEY  (`id_et`,`id_f`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `reg_et`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `reg_fr`
-- 

CREATE TABLE `reg_fr` (
  `id_reg` int(10) NOT NULL,
  `lib_reg` varchar(100) NOT NULL,
  `dat_fr_rg` date NOT NULL,
  `debit_fr_reg` float NOT NULL,
  `credit_fr_reg` float NOT NULL,
  `solde_fe_reg` float NOT NULL,
  `rest_fr_reg` float NOT NULL,
  `mod_pay_fr_reg` varchar(10) NOT NULL,
  `echeance_fr_reg` float NOT NULL,
  `retenu_fr_reg` float NOT NULL,
  `observ_fr_reg` text NOT NULL,
  `id_fr` int(10) NOT NULL,
  PRIMARY KEY  (`id_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `reg_fr`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `salle`
-- 

CREATE TABLE `salle` (
  `id_sal` varchar(50) NOT NULL,
  `lib_sal` varchar(50) NOT NULL,
  `capacite_sal` int(3) NOT NULL,
  `id_f` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_sal`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `salle`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `seance`
-- 

CREATE TABLE `seance` (
  `id_s` int(10) NOT NULL auto_increment,
  `lib_s` varchar(50) NOT NULL,
  `dure_s` int(2) NOT NULL,
  `dat_d_s` date NOT NULL,
  `dat_f_s` date NOT NULL,
  `idèf` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_s`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Contenu de la table `seance`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `utilisateur`
-- 

CREATE TABLE `utilisateur` (
  `id_util` varchar(50) NOT NULL,
  `login_util` varchar(10) NOT NULL,
  `pass_util` varchar(32) NOT NULL,
  `nom_util` varchar(60) NOT NULL,
  `prenom_util` varchar(50) NOT NULL,
  `mail_util` varchar(70) NOT NULL,
  `fonction_util` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_util`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `utilisateur`
-- 

INSERT INTO `utilisateur` VALUES ('uitl1', 'nadia', 'nadia', 'kh', 'nad', 'nad@yahoo.fr', 'secrutaire');
INSERT INTO `utilisateur` VALUES ('util2', 'souma', 'souma', 'kh', 'islem', 'souma@yahoo.fr', 'financiére');
